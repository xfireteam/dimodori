package com.jellycine.shared.ui.components.common

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.jellycine.data.model.BaseItemDto
import com.jellycine.data.model.BaseItemPerson
import com.jellycine.data.repository.MediaRepository
import com.jellycine.shared.R
import com.jellycine.shared.util.image.primaryImageTagOrNull
import kotlinx.coroutines.flow.first

@Composable
fun CastSection(
    item: BaseItemDto,
    mediaRepository: MediaRepository,
    modifier: Modifier = Modifier,
    title: String? = null,
    onPersonClick: (String) -> Unit = {}
) {
    val sectionTitle = title ?: stringResource(R.string.detail_cast_and_crew)
    val castAndCrew = remember(item.people) {
        prioritizeCastAndCrew(people = item.people)
    }

    if (castAndCrew.isNotEmpty()) {
        Column(modifier = modifier) {
            Text(
                text = sectionTitle,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 0.dp)
            ) {
                itemsIndexed(
                    items = castAndCrew,
                    key = { index, person ->
                        "${person.id ?: "${person.name}-${person.role}-${person.type}"}_$index"
                    }
                ) { _, person ->
                    CastCrewMemberCard(
                        person = person,
                        mediaRepository = mediaRepository,
                        onClick = {
                            person.id?.takeIf { it.isNotBlank() }?.let(onPersonClick)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CastCrewMemberCard(
    person: BaseItemPerson,
    mediaRepository: MediaRepository,
    onClick: () -> Unit
) {
    var personImageUrl by remember(person.id) { mutableStateOf<String?>(null) }
    val hasValidPersonId = !person.id.isNullOrBlank()

    LaunchedEffect(person.id, person.primaryImageTag, person.imageUrl) {
        if (!person.imageUrl.isNullOrBlank()) {
            personImageUrl = person.imageUrl
        } else {
            person.id?.let { id ->
                personImageUrl = getPersonImageUrl(
                    personId = id,
                    imageTag = person.primaryImageTagOrNull(),
                    mediaRepository = mediaRepository
                )
            }
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(116.dp)
            .clickable(
                enabled = hasValidPersonId,
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(166.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF2A2A2A)),
            contentAlignment = Alignment.Center
        ) {
            if (personImageUrl != null) {
                AsyncImage(
                    model = personImageUrl,
                    contentDescription = person.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Person,
                    contentDescription = person.name,
                    tint = Color.White.copy(alpha = 0.4f),
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = person.name ?: stringResource(R.string.detail_similar_item_unknown),
            fontSize = 12.sp,
            color = Color.White,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.Medium,
            lineHeight = 14.sp
        )

        val roleLabel = person.role?.takeIf { it.isNotBlank() }
            ?: person.type?.takeIf { !it.equals("Actor", ignoreCase = true) && it.isNotBlank() }

        roleLabel?.let { role ->
            Text(
                text = role,
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.62f),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 1.dp)
            )
        }
    }
}

private fun prioritizeCastAndCrew(
    people: List<BaseItemPerson>?
): List<BaseItemPerson> {
    if (people.isNullOrEmpty()) return emptyList()

    val clean = people.filter { !it.name.isNullOrBlank() }
    if (clean.isEmpty()) return emptyList()

    val actors = clean.filter { it.type.equals("Actor", ignoreCase = true) }
    val crew = clean.filterNot { it.type.equals("Actor", ignoreCase = true) }

    return (actors + crew)
        .distinctBy { it.id ?: "${it.name}-${it.role}-${it.type}" }
}

private suspend fun getPersonImageUrl(
    personId: String,
    imageTag: String?,
    mediaRepository: MediaRepository
): String? {
    return mediaRepository.getImageUrl(
        itemId = personId,
        imageType = "Primary",
        width = 320,
        height = 480,
        quality = 90,
        imageTag = imageTag
    ).first()
}