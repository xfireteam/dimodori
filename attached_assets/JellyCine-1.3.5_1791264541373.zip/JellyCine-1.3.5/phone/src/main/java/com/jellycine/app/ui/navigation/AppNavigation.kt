package com.jellycine.app.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.jellycine.app.ui.screens.dashboard.DashboardContainer
import com.jellycine.app.ui.screens.auth.AuthScreen
import com.jellycine.app.ui.screens.dashboard.media.isSeerrCatalog
import com.jellycine.app.ui.screens.detail.DetailScreenContainer
import com.jellycine.app.ui.screens.detail.PersonScreenContainer
import com.jellycine.app.ui.screens.dashboard.settings.DownloadsScreen
import com.jellycine.app.ui.screens.dashboard.settings.CacheSettingsScreen
import com.jellycine.app.ui.screens.dashboard.settings.ConnectionsSettingsScreen
import com.jellycine.app.ui.screens.admin.ServerInfoScreen
import com.jellycine.app.ui.screens.dashboard.settings.AboutScreen
import com.jellycine.app.ui.screens.dashboard.settings.PlayerSettingsScreen
import com.jellycine.app.ui.screens.dashboard.settings.SubtitleSettingsScreen
import com.jellycine.app.ui.screens.dashboard.settings.InterfaceSettingsScreen
import com.jellycine.app.ui.screens.player.PlayerScreen
import com.jellycine.app.ui.screens.screentime.ScreenTimeScreen
import com.jellycine.app.player.mpv.MpvWarmPool
import com.jellycine.auth.AuthStateManager
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.delay

// Pure Animation helpers - no sliding, only fade with content transforms
private fun textTransition(duration: Int = 400): EnterTransition {
    return fadeIn(animationSpec = tween(duration, easing = FastOutSlowInEasing))
}

private fun textExitTransition(duration: Int = 300): ExitTransition {
    return fadeOut(animationSpec = tween(duration, easing = LinearOutSlowInEasing))
}

@UnstableApi
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val authStateManager = remember { AuthStateManager.getInstance(context) }

    var startDestination by remember { mutableStateOf<String?>(null) }
    
    LaunchedEffect(Unit) {
        val isAuthenticated = authStateManager.checkAuthenticationState()
        startDestination = if (isAuthenticated) "dashboard" else "auth"
    }

    if (startDestination == null) return

    NavHost(
        navController = navController,
        startDestination = startDestination!!,
        modifier = Modifier.fillMaxSize()
    ) {
            composable(
                "splash",
                enterTransition = { textTransition(500) },
                exitTransition = {
                    if (targetState.destination.route == "server_connection") {
                        ExitTransition.None
                    } else {
                        textExitTransition(400)
                    }
                }
            ) {
                AuthScreen(
                    preferSavedServers = true,
                    onAddServer = {
                        navController.navigate("server_connection") {
                            popUpTo("splash") { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                    onAuthSuccess = {
                        navController.navigate("dashboard") {
                            popUpTo("splash") { inclusive = true }
                        }
                    }
                )
            }

            composable(
                "auth",
                enterTransition = {
                    if (initialState.destination.route == "dashboard") {
                        EnterTransition.None
                    } else {
                        textTransition(500)
                    }
                },
                exitTransition = {
                    if (targetState.destination.route == "server_connection") {
                        ExitTransition.None
                    } else {
                        textExitTransition(400)
                    }
                }
            ) {
                AuthScreen(
                    preferSavedServers = true,
                    onAddServer = {
                        navController.navigate("server_connection") {
                            popUpTo("auth") { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                    onAuthSuccess = {
                        navController.navigate("dashboard") {
                            popUpTo("auth") { inclusive = true }
                        }
                    }
                )
            }

            composable(
                "server_connection",
                enterTransition = {
                    if (
                        initialState.destination.route == "auth" ||
                        initialState.destination.route == "splash"
                    ) {
                        EnterTransition.None
                    } else {
                        textTransition(500)
                    }
                },
                exitTransition = { textExitTransition(400) }
            ) {
                AuthScreen(
                    onAuthSuccess = {
                        navController.navigate("dashboard") {
                            popUpTo("server_connection") { inclusive = true }
                        }
                    }
                )
            }

            composable(
                "add_user?serverUrl={serverUrl}&serverName={serverName}",
                arguments = listOf(
                    navArgument("serverUrl") {
                        type = NavType.StringType
                        defaultValue = ""
                    },
                    navArgument("serverName") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                ),
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) { backStackEntry ->
                val encodedServerUrl = backStackEntry.arguments?.getString("serverUrl").orEmpty()
                val serverUrl = runCatching {
                    java.net.URLDecoder.decode(encodedServerUrl, "UTF-8")
                }.getOrDefault(encodedServerUrl)
                val encodedServerName = backStackEntry.arguments?.getString("serverName")
                val serverName = encodedServerName?.let { encodedName ->
                    runCatching { java.net.URLDecoder.decode(encodedName, "UTF-8") }
                        .getOrDefault(encodedName)
                }?.takeIf { it.isNotBlank() }

                AuthScreen(
                    serverUrl = serverUrl.takeIf { it.isNotBlank() },
                    serverName = serverName,
                    startAtLogin = serverUrl.isNotBlank(),
                    onAuthSuccess = {
                        val popped = navController.popBackStack()
                        if (!popped) {
                            navController.navigate("dashboard") {
                                launchSingleTop = true
                            }
                        }
                    }
                )
            }

            composable(
                "dashboard",
                enterTransition = { textTransition(400) },
                exitTransition = {
                    if (targetState.destination.route == "auth") {
                        ExitTransition.None
                    } else {
                        textExitTransition(300)
                    }
                }
            ) {
                LaunchedEffect(Unit) {
                    delay(750L)
                    MpvWarmPool.warmIfPreferred(context.applicationContext)
                }

                DashboardContainer(
                    onLogout = {
                        navController.navigate("auth") {
                            popUpTo("dashboard") { inclusive = true }
                        }
                    },
                    onNavigateToPlayerSettings = {
                        navController.navigate("player_settings")
                    },
                    onNavigateToInterfaceSettings = {
                        navController.navigate("interface_settings")
                    },
                    onNavigateToConnections = {
                        navController.navigate("connections_settings")
                    },
                    onNavigateToDownloads = {
                        navController.navigate("downloads")
                    },
                    onNavigateToCacheSettings = {
                        navController.navigate("cache_settings")
                    },
                    onNavigateToAbout = {
                        navController.navigate("about")
                    },
                    onNavigateToServerInfo = {
                        navController.navigate("server_info")
                    },
                    onNavigateToScreenTime = {
                        navController.navigate("screen_time")
                    },
                    onAddServer = {
                        navController.navigate("server_connection") {
                            launchSingleTop = true
                        }
                    },
                    onAddUser = { serverUrl, serverName ->
                        val encodedServerUrl = java.net.URLEncoder.encode(serverUrl, "UTF-8")
                        val encodedServerName = java.net.URLEncoder.encode(serverName.orEmpty(), "UTF-8")
                        navController.navigate(
                            "add_user?serverUrl=$encodedServerUrl&serverName=$encodedServerName"
                        ) {
                            launchSingleTop = true
                        }
                    },
                    onNavigateToDetail = { item ->
                        item.id?.let { itemId ->
                            navController.navigate("detail/$itemId?mergeVersions=true")
                        }
                    },
                    onNavigateToMergedDetail = { item ->
                        item.id?.let { itemId ->
                            navController.navigate("detail/$itemId?mergeVersions=true")
                        }
                    },
                    onNavigateToViewAll = { contentType, parentId, title ->
                        val encodedTitle = java.net.URLEncoder.encode(title, "UTF-8")
                        val route = when {
                            contentType.contains("GENRE") && parentId != null -> {
                                "viewall/$contentType?genreId=$parentId&title=$encodedTitle"
                            }
                            parentId != null -> {
                                "viewall/$contentType?parentId=$parentId&title=$encodedTitle"
                            }
                            else -> {
                                "viewall/$contentType?title=$encodedTitle"
                            }
                        }
                        navController.navigate(route)
                    },
                    onNavigateToPlayer = { itemId ->
                        navController.navigate("player/$itemId")
                    }
                )
            }

            composable(
                "player/{itemId}",
                arguments = listOf(navArgument("itemId") { type = NavType.StringType }),
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) { backStackEntry ->
                val itemId = backStackEntry.arguments?.getString("itemId")

                if (!itemId.isNullOrBlank()) {
                    PlayerScreen(
                        mediaId = itemId,
                        onBackPressed = { navController.popBackStack() }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        navController.popBackStack()
                    }
                }
            }

            composable(
                "detail/{itemId}?mergeVersions={mergeVersions}",
                arguments = listOf(
                    navArgument("itemId") { type = NavType.StringType },
                    navArgument("mergeVersions") {
                        type = NavType.BoolType
                        defaultValue = false
                    }
                ),
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) { backStackEntry ->
                val itemId = backStackEntry.arguments?.getString("itemId")
                val forceMergeVersions = backStackEntry.arguments?.getBoolean("mergeVersions") ?: false

                if (itemId != null) {
                    DetailScreenContainer(
                        itemId = itemId,
                        forceMergeVersions = forceMergeVersions,
                        onNavigateToDetail = { selectedItemId ->
                            if (selectedItemId != itemId) {
                                navController.navigate("detail/$selectedItemId?mergeVersions=true")
                            }
                        },
                        onNavigateToPerson = { personId ->
                            if (personId != itemId) {
                                navController.navigate("person/$personId")
                            }
                        },
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        navController.popBackStack()
                    }
                }
            }

            composable(
                "episode/{episodeId}",
                arguments = listOf(navArgument("episodeId") { type = NavType.StringType }),
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) { backStackEntry ->
                val episodeId = backStackEntry.arguments?.getString("episodeId")

                if (episodeId != null) {
                    DetailScreenContainer(
                        itemId = episodeId,
                        onNavigateToDetail = { selectedItemId ->
                            if (selectedItemId != episodeId) {
                                navController.navigate("detail/$selectedItemId?mergeVersions=true")
                            }
                        },
                        onNavigateToPerson = { personId ->
                            if (personId != episodeId) {
                                navController.navigate("person/$personId")
                            }
                        },
                        onBackPressed = {
                            navController.popBackStack()
                        }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        navController.popBackStack()
                    }
                }
            }

            composable(
                "person/{personId}",
                arguments = listOf(navArgument("personId") { type = NavType.StringType }),
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) { backStackEntry ->
                val personId = backStackEntry.arguments?.getString("personId")

                if (personId != null) {
                    PersonScreenContainer(
                        personId = personId,
                        onBackPressed = {
                            navController.popBackStack()
                        },
                        onItemClick = { selectedItemId ->
                            navController.navigate("detail/$selectedItemId?mergeVersions=true")
                        }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        navController.popBackStack()
                    }
                }
            }

            composable(
                "viewall/{contentType}?parentId={parentId}&title={title}&genreId={genreId}",
                arguments = listOf(
                    navArgument("contentType") { type = NavType.StringType },
                    navArgument("parentId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    },
                    navArgument("title") {
                        type = NavType.StringType
                        defaultValue = "View All"
                    },
                    navArgument("genreId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                ),
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) { backStackEntry ->
                val contentTypeString = backStackEntry.arguments?.getString("contentType") ?: "ALL"
                val parentId = backStackEntry.arguments?.getString("parentId")
                val genreId = backStackEntry.arguments?.getString("genreId")
                val title = backStackEntry.arguments?.getString("title")?.let {
                    java.net.URLDecoder.decode(it, "UTF-8")
                } ?: "View All"

                val contentType = when (contentTypeString.uppercase()) {
                    "MOVIES" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.MOVIES
                    "SERIES" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.SERIES
                    "EPISODES" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.EPISODES
                    "MOVIES_GENRE" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.MOVIES_GENRE
                    "TVSHOWS_GENRE" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.TVSHOWS_GENRE
                    "SEERR_STUDIO" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.SEERR_STUDIO
                    "SEERR_NETWORK" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.SEERR_NETWORK
                    "AWARD" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.AWARD
                    else -> com.jellycine.app.ui.screens.dashboard.media.ContentType.ALL
                }

                com.jellycine.app.ui.screens.dashboard.media.ViewAllScreen(
                    contentType = contentType,
                    parentId = parentId,
                    genreId = genreId,
                    title = title,
                    onBackPressed = { navController.popBackStack() },
                    onItemClick = { item ->
                        item.id?.let { itemId ->
                            val mergeVersions = parentId == com.jellycine.app.ui.screens.dashboard.media.WATCHED_VIEW_ALL_PARENT_ID ||
                                contentType.isSeerrCatalog()
                            navController.navigate("detail/$itemId${if (mergeVersions) "?mergeVersions=true" else ""}")
                        }
                    }
                )
            }

            composable(
                "player_settings",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                PlayerSettingsScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    },
                    onNavigateToSubtitleSettings = {
                        navController.navigate("subtitle_settings")
                    }
                )
            }

            composable(
                "subtitle_settings",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                SubtitleSettingsScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                "downloads",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                DownloadsScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                "interface_settings",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                InterfaceSettingsScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                "connections_settings",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                ConnectionsSettingsScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    },
                    onNavigateToRequestedItem = { item ->
                        navController.navigate("detail/${item.id}")
                    }
                )
            }

            composable(
                "cache_settings",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                CacheSettingsScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                "about",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                AboutScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                "server_info",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                ServerInfoScreen(
                    onBackPressed = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                "screen_time",
                enterTransition = { textTransition(500) },
                exitTransition = { textExitTransition(400) }
            ) {
                ScreenTimeScreen(
                    onBack = { navController.popBackStack() }
                )
            }
        }
}