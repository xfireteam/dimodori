package com.jellycine.app.ui.screens.dashboard.media

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import coil3.compose.AsyncImage
import coil3.request.*
import kotlinx.coroutines.flow.first
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jellycine.shared.R
import com.jellycine.app.ui.components.common.CompactPageHeader
import com.jellycine.app.ui.components.common.CompactTopText
import com.jellycine.app.ui.components.common.rememberCompactProgress
import com.jellycine.shared.util.image.disableEmbyPosterEnhancers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun MyMedia(
    onLibraryClick: (com.jellycine.app.ui.screens.dashboard.media.ContentType, String?, String) -> Unit = { _, _, _ -> }
) {
    var libraryViews by remember { mutableStateOf<List<com.jellycine.data.model.BaseItemDto>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var refreshing by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val mediaRepository = remember { com.jellycine.data.repository.MediaRepositoryProvider.getInstance(context) }
    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()
    val libraryImageUrls = remember { mutableStateMapOf<String, String?>() }
    val disablePosterEnhancers = disableEmbyPosterEnhancers()
    val compactHeaderProgress = rememberCompactProgress(
        state = gridState,
        compactDistance = 92.dp
    )
    val headerTitle = stringResource(R.string.my_media)
    val libraryCountText = if (libraryViews.isNotEmpty()) {
        pluralStringResource(
            R.plurals.my_media_libraries_available,
            libraryViews.size,
            libraryViews.size
        )
    } else {
        null
    }
    val compactHeaderTitle = if (libraryViews.isNotEmpty()) {
        "$headerTitle (${libraryViews.size})"
    } else {
        headerTitle
    }

    @Composable
    fun HeaderContent(
        modifier: Modifier = Modifier,
        horizontalPadding: Dp = 20.dp
    ) {
        CompactPageHeader(
            title = headerTitle,
            subtitle = libraryCountText,
            includeStatusBarsPadding = false,
            horizontalPadding = horizontalPadding,
            verticalPadding = 24.dp,
            titleFontSize = 32.sp,
            titleFontWeight = FontWeight.Bold,
            modifier = modifier
        )
    }

    LaunchedEffect(disablePosterEnhancers) {
        libraryImageUrls.clear()
    }

    // Loading function
    suspend fun loadLibraries(showRefreshIndicator: Boolean = false) {
        if (showRefreshIndicator) refreshing = true

        try {
            withContext(Dispatchers.IO) {
                val result = mediaRepository.getUserViews()

                withContext(Dispatchers.Main) {
                    result.fold(
                        onSuccess = { queryResult ->
                            val validViews = queryResult.items?.filter {
                                it.id != null &&
                                !it.name.isNullOrBlank() &&
                                it.collectionType != "playlists" &&
                                it.collectionType != "folders" &&
                                (it.type == "CollectionFolder" || it.type == "Folder")
                            } ?: emptyList()

                            libraryViews = validViews
                            isLoading = false
                            error = null
                        },
                        onFailure = { throwable ->
                            error = throwable.message ?: context.getString(R.string.my_media_load_error)
                            isLoading = false
                        }
                    )
                }
            }
        } catch (e: Exception) {
            error = e.message ?: context.getString(R.string.my_media_unknown_error)
            isLoading = false
        } finally {
            refreshing = false
        }
    }

    // Load library views
    LaunchedEffect(Unit) {
        loadLibraries()
    }

    // Resolve and cache library image URLs once per library id to avoid recycle flicker/jank.
    LaunchedEffect(libraryViews, disablePosterEnhancers) {
        val idsToLoad = libraryViews
            .mapNotNull { it.id }
            .filterNot { libraryImageUrls.containsKey(it) }

        if (idsToLoad.isEmpty()) return@LaunchedEffect

        for (itemId in idsToLoad) {
            val url = withContext(Dispatchers.IO) {
                runCatching {
                    mediaRepository.getImageUrl(
                        itemId = itemId,
                        width = 400,
                        height = 300,
                        quality = 90,
                        enableImageEnhancers = !disablePosterEnhancers
                    ).first()
                }.getOrNull()
            }
            libraryImageUrls[itemId] = url
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            if (libraryViews.isEmpty()) {
                HeaderContent()
            }

            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                when {
                    isLoading -> {
                        // Loading state with grid layout
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 120.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalArrangement = Arrangement.spacedBy(20.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(8) { index ->
                                LibraryCardSkeleton(
                                    animationDelay = index * 100
                                )
                            }
                        }
                    }

                    error != null -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = Color.Red.copy(alpha = 0.7f),
                                    modifier = Modifier.size(48.dp)
                                )
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                Text(
                                    text = stringResource(R.string.my_media_load_error),
                                    color = Color.White,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                                
                                Text(
                                    text = error ?: stringResource(R.string.my_media_unknown_error),
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                                
                                Button(
                                    onClick = { 
                                        coroutineScope.launch {
                                            isLoading = true
                                            error = null
                                            loadLibraries()
                                        }
                                    },
                                    modifier = Modifier.padding(top = 24.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF0080FF)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        stringResource(R.string.try_again),
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    libraryViews.isEmpty() -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VideoLibrary,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.4f),
                                    modifier = Modifier.size(64.dp)
                                )
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                Text(
                                    text = stringResource(R.string.my_media_empty_title),
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                
                                Text(
                                    text = stringResource(R.string.my_media_empty_message),
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    else -> {
                        // Grid layout with visual cards
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            state = gridState,
                            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 0.dp, bottom = 120.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalArrangement = Arrangement.spacedBy(20.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                HeaderContent(
                                    horizontalPadding = 0.dp,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            itemsIndexed(
                                items = libraryViews,
                                key = { index, library ->
                                    "${library.id ?: "${library.name.orEmpty()}_${library.collectionType.orEmpty()}"}_$index"
                                }
                            ) { _, library ->
                                VisualLibraryCard(
                                    library = library,
                                    imageUrl = library.id?.let { id -> libraryImageUrls[id] },
                                    onClick = {
                                        val contentType = when (library.collectionType) {
                                            "movies" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.MOVIES
                                            "tvshows" -> com.jellycine.app.ui.screens.dashboard.media.ContentType.SERIES
                                            else -> com.jellycine.app.ui.screens.dashboard.media.ContentType.ALL
                                        }
                                        onLibraryClick(
                                            contentType,
                                            library.id,
                                            library.name ?: context.getString(R.string.my_media_library_fallback)
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (libraryViews.isNotEmpty()) {
            CompactTopText(
                text = compactHeaderTitle,
                progress = compactHeaderProgress,
                isTablet = false,
                onClick = {
                    coroutineScope.launch {
                        gridState.animateScrollToItem(0)
                    }
                },
                modifier = Modifier.align(Alignment.TopStart)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VisualLibraryCard(
    library: com.jellycine.data.model.BaseItemDto,
    imageUrl: String?,
    onClick: () -> Unit
) {
    val context = LocalContext.current

    val itemCount = when {
        library.childCount != null && library.childCount!! > 0 -> library.childCount!!
        library.recursiveItemCount != null && library.recursiveItemCount!! > 0 -> library.recursiveItemCount!!
        else -> 0
    }
    val cardShape = RoundedCornerShape(16.dp)
    
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.2f),
            shape = cardShape,
            colors = CardDefaults.cardColors(
                containerColor = Color.Transparent
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 3.dp,
                pressedElevation = 5.dp
            ),
            onClick = onClick
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(cardShape)
            ) {
                if (imageUrl != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(imageUrl)
                            .crossfade(false)
                            .memoryCachePolicy(CachePolicy.ENABLED)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .networkCachePolicy(CachePolicy.ENABLED)
                            .build(),
                        contentDescription = library.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                color = Color(0xFF161616),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getLibraryIcon(library.collectionType),
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.45f),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            }
        }

        val libraryName = library.name ?: stringResource(R.string.my_media_library_fallback)
        val subtitle = if (itemCount > 0) {
            pluralStringResource(R.plurals.my_media_items_count, itemCount, itemCount)
        } else {
            getLibraryTypeText(library.collectionType)
        }

        Text(
            text = libraryName,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp, start = 2.dp, end = 2.dp)
        )
        Text(
            text = subtitle,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 2.dp, start = 2.dp, end = 2.dp)
        )
    }
}

@Composable
private fun LibraryCardSkeleton(
    animationDelay: Int = 0
) {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, delayMillis = animationDelay),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1.2f),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = shimmerAlpha * 0.1f),
                                Color.White.copy(alpha = shimmerAlpha * 0.15f)
                            )
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                Color.White.copy(alpha = shimmerAlpha * 0.2f),
                                RoundedCornerShape(8.dp)
                            )
                    )
                }

                // Bottom text skeleton
                Column {
                    // Title skeleton
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(18.dp)
                            .background(
                                Color.White.copy(alpha = shimmerAlpha * 0.25f),
                                RoundedCornerShape(6.dp)
                            )
                    )
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    // Subtitle skeleton
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .height(13.dp)
                            .background(
                                Color.White.copy(alpha = shimmerAlpha * 0.15f),
                                RoundedCornerShape(4.dp)
                            )
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(20.dp)
                            .background(
                                Color.White.copy(alpha = shimmerAlpha * 0.12f),
                                RoundedCornerShape(12.dp)
                            )
                    )
                }
            }
        }
    }
}

private fun getLibraryIcon(collectionType: String?): ImageVector {
    return when (collectionType) {
        "movies" -> Icons.Filled.Movie
        "tvshows" -> Icons.Filled.Tv
        else -> Icons.Filled.VideoLibrary
    }
}

@Composable
private fun getLibraryTypeText(collectionType: String?): String {
    return when (collectionType) {
        "movies" -> stringResource(R.string.movies)
        "tvshows" -> stringResource(R.string.tv_shows)
        else -> stringResource(R.string.my_media_library_type_library)
    }
}