package com.jellycine.app.ui.screens.dashboard.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import coil3.compose.AsyncImage
import coil3.compose.AsyncImagePainter
import coil3.compose.rememberAsyncImagePainter
import coil3.imageLoader
import coil3.request.*
import com.jellycine.shared.R
import com.jellycine.app.ui.components.common.ScreenCastButton
import com.jellycine.app.ui.screens.auth.ProfileImageLoader
import com.jellycine.shared.util.image.imageTagFor
import com.jellycine.data.model.BaseItemDto
import com.jellycine.data.model.PersistedHomeSnapshot
import com.jellycine.data.repository.AuthRepository.ActiveSessionSnapshot
import com.jellycine.data.repository.AuthRepositoryProvider
import com.jellycine.data.repository.MediaRepositoryProvider
import com.jellycine.shared.preferences.Preferences
import com.jellycine.app.ui.components.common.InlineTrailerPlayer
import androidx.compose.ui.platform.LocalConfiguration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs


internal object CachedData {
    var featuredItems: List<BaseItemDto> = emptyList()
    var lastLoadTime: Long = 0
    private var _isCurrentlyLoading: Boolean = false

    val isCurrentlyLoading: Boolean get() = _isCurrentlyLoading

    fun shouldRefresh(): Boolean {
        return featuredItems.isEmpty() || System.currentTimeMillis() - lastLoadTime > 300_000
    }

    fun updateFeaturedItems(items: List<BaseItemDto>) {
        featuredItems = items
        lastLoadTime = System.currentTimeMillis()
        _isCurrentlyLoading = false
    }

    fun clearAllCache() {
        featuredItems = emptyList()
        lastLoadTime = 0
        _isCurrentlyLoading = false
    }

    fun markAsLoading(loading: Boolean) {
        _isCurrentlyLoading = loading
    }
}

private data class FeatureCardImages(
    val lowBackdropUrl: String?,
    val backdropUrl: String?,
    val logoUrl: String?,
    val versionKey: String? = null
)

@Composable
@Suppress("UNUSED_PARAMETER")
@OptIn(ExperimentalFoundationApi::class)
fun FeatureTab(
    modifier: Modifier = Modifier,
    featuredItems: List<BaseItemDto> = emptyList(),
    isLoading: Boolean = true,
    error: String? = null,
    selectedCategory: String = HomeCategory.HOME,
    carouselHeight: String = Preferences.FEATURE_CAROUSEL_HEIGHT_LARGE,
    verticalParallaxOffsetPx: Float = 0f,
    onItemClick: (BaseItemDto) -> Unit = {},
    onLogout: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    onCastButtonClick: () -> Unit = {},
    onCategorySelected: (String) -> Unit = {},
    refreshTrigger: Int = 0
) {
    val context = LocalContext.current
    val mediaRepository = remember { MediaRepositoryProvider.getInstance(context) }
    val authRepository = remember { AuthRepositoryProvider.getInstance(context) }
    val preferences = remember { Preferences(context) }
    val userFallback = stringResource(R.string.settings_unknown_user)
    var persistedHomeSnapshot by remember {
        mutableStateOf<PersistedHomeSnapshot?>(mediaRepository.getPersistedHomeSnapshot())
    }
    val sessionSnapshot by authRepository.observeActiveSession().collectAsState(
        initial = ActiveSessionSnapshot(
            serverName = null,
            serverUrl = null,
            serverType = null,
            username = null,
            savedServers = emptyList(),
            activeServerId = null
        )
    )
    val currentUsername = sessionSnapshot.username ?: persistedHomeSnapshot?.username
    val currentServerUrl = sessionSnapshot.serverUrl ?: persistedHomeSnapshot?.serverUrl
    var displayUsername by rememberSaveable(currentUsername, currentServerUrl) {
        mutableStateOf(currentUsername ?: persistedHomeSnapshot?.username ?: userFallback)
    }
    var userProfileImageUrl by rememberSaveable(currentUsername, currentServerUrl) {
        mutableStateOf<String?>(persistedHomeSnapshot?.profileImageUrl)
    }

    val configuration = LocalConfiguration.current
    val featuredRowState = remember(
        selectedCategory,
        carouselHeight,
        configuration.screenWidthDp,
        configuration.screenHeightDp
    ) { LazyListState() }
    val featuredFlingBehavior = rememberSnapFlingBehavior(lazyListState = featuredRowState)
    val imageCacheByItemId = remember { mutableStateMapOf<String, FeatureCardImages>() }
    val preloadedItemIds = remember { mutableStateListOf<String>() }
    var stableFeaturedItems by remember(selectedCategory) { mutableStateOf<List<BaseItemDto>>(emptyList()) }
    val metadataQualifiedFeaturedItems = remember(featuredItems) {
        derivedStateOf {
            featuredItems.filter(::hasFeatureHeroAssets)
        }
    }
    val visibleRealIndex by remember(featuredRowState) {
        derivedStateOf {
            val size = stableFeaturedItems.size
            if (size == 0) -1 else featuredRowState.firstVisibleItemIndex % size
        }
    }
    val resolvedFeaturedItems = remember(
        metadataQualifiedFeaturedItems.value,
        stableFeaturedItems,
        preloadedItemIds.size,
        visibleRealIndex
    ) {
        derivedStateOf {
            val targetItems = metadataQualifiedFeaturedItems.value
            if (targetItems.isEmpty()) return@derivedStateOf stableFeaturedItems
            if (stableFeaturedItems.isEmpty()) return@derivedStateOf targetItems

            val stableSize = stableFeaturedItems.size
            buildList(stableSize) {
                for (i in 0 until stableSize) {
                    val target = targetItems.getOrNull(i)
                    if (target != null && target.id.orEmpty() in preloadedItemIds && i != visibleRealIndex) {
                        add(target)
                    } else {
                        add(stableFeaturedItems[i])
                    }
                }
            }
        }
    }

    LaunchedEffect(metadataQualifiedFeaturedItems.value, preloadedItemIds.size) {
        val targetItems = metadataQualifiedFeaturedItems.value
        if (targetItems.isNotEmpty() && targetItems.all { it.id.orEmpty() in preloadedItemIds }) {
            stableFeaturedItems = targetItems
        }
    }

    val featuredKeys = remember(resolvedFeaturedItems.value) {
        resolvedFeaturedItems.value.indices.map { it.toString() }
    }
    val isFeatureAssets = remember(
        isLoading,
        featuredItems,
        metadataQualifiedFeaturedItems.value,
        resolvedFeaturedItems.value
    ) {
        !isLoading &&
            featuredItems.isNotEmpty() &&
            metadataQualifiedFeaturedItems.value.isNotEmpty() &&
            resolvedFeaturedItems.value.isEmpty()
    }
    val infiniteStartIndex = remember(featuredKeys) {
        if (featuredKeys.isEmpty()) 0 else (Int.MAX_VALUE / 2) - ((Int.MAX_VALUE / 2) % featuredKeys.size)
    }
    var autoScroll by rememberSaveable(selectedCategory, carouselHeight) { mutableStateOf(false) }
    var isAutoScrolling by remember { mutableStateOf(false) }
    val autoplayTrailersEnabled by preferences.autoplayTrailersEnabled()
        .collectAsState(initial = preferences.isAutoplayTrailersEnabled())
    val isAutoplayAllowed = autoplayTrailersEnabled &&
            (carouselHeight == Preferences.FEATURE_CAROUSEL_HEIGHT_MEDIUM ||
             carouselHeight == Preferences.FEATURE_CAROUSEL_HEIGHT_SMALL)
    var currentPlayingTrailerUrl by remember { mutableStateOf<String?>(null) }
    var isTrailerPlaying by remember { mutableStateOf(false) }
    var trailerPlaybackCompleted by remember { mutableStateOf(false) }
    var hasSeededCarousel by remember(
        selectedCategory,
        carouselHeight,
        configuration.screenWidthDp,
        configuration.screenHeightDp
    ) { mutableStateOf(false) }
    val heroSizing = remember(configuration.screenHeightDp, carouselHeight) {
        featureHeroSizing(
            heightMode = carouselHeight,
            screenHeight = configuration.screenHeightDp.dp
        )
    }
    val screenWidth = configuration.screenWidthDp.dp
    val heroHeight = heroSizing.height
    val heroViewportHeight = heroHeight + heroSizing.carouselTopPadding
    val heroCardWidth = remember(screenWidth, heroSizing) {
        heroSizing.compactCardWidth(screenWidth)
    }
    val centeredCardIndex by remember(featuredRowState) {
        derivedStateOf {
            val layoutInfo = featuredRowState.layoutInfo
            if (layoutInfo.visibleItemsInfo.isEmpty()) return@derivedStateOf featuredRowState.firstVisibleItemIndex
            val viewportCenter = layoutInfo.viewportStartOffset + layoutInfo.viewportSize.width / 2
            layoutInfo.visibleItemsInfo.minByOrNull { item ->
                val itemCenter = item.offset + item.size / 2
                abs(itemCenter - viewportCenter)
            }?.index ?: featuredRowState.firstVisibleItemIndex
        }
    }
    val density = LocalDensity.current
    val initialCarouselIndex = remember(heroSizing, infiniteStartIndex) {
        heroSizing.initialCarouselIndex(infiniteStartIndex)
    }
    val initialCarouselScrollOffsetPx = remember(
        screenWidth,
        heroCardWidth,
        density,
        heroSizing
    ) {
        heroSizing.initialCarouselScrollOffsetPx(
            screenWidth = screenWidth,
            cardWidth = heroCardWidth,
            density = density
        )
    }

    LaunchedEffect(currentServerUrl, currentUsername) {
        persistedHomeSnapshot = mediaRepository.loadPersistedHomeSnapshot()
    }

    LaunchedEffect(currentUsername, currentServerUrl, refreshTrigger) {
        val activeUsername = currentUsername ?: persistedHomeSnapshot?.username
        displayUsername = activeUsername?.takeIf { it.isNotBlank() } ?: "User"

        val persistedProfileUrl = persistedHomeSnapshot?.profileImageUrl
        if (!persistedProfileUrl.isNullOrBlank()) {
            userProfileImageUrl = persistedProfileUrl
        }

        val user = withContext(Dispatchers.IO) {
            try {
                mediaRepository.getCurrentUser().getOrNull()
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                null
            }
        }
        currentCoroutineContext().ensureActive()
        val profileUrl = withContext(Dispatchers.IO) {
            try {
                mediaRepository.getUserProfileImageUrl(user?.primaryImageTag)
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                null
            }
        }
        currentCoroutineContext().ensureActive()
        userProfileImageUrl = profileUrl
        authRepository.updateActiveServerProfileImage(
            profileImageUrl = profileUrl ?: persistedProfileUrl
        )
    }

    LaunchedEffect(featuredItems, isLoading) {
        CachedData.markAsLoading(isLoading)
        if (featuredItems.isNotEmpty()) {
            CachedData.updateFeaturedItems(featuredItems)
        }
    }

    LaunchedEffect(featuredKeys, isLoading, selectedCategory, initialCarouselIndex, initialCarouselScrollOffsetPx) {
        if (isLoading || resolvedFeaturedItems.value.size <= 1 || hasSeededCarousel) return@LaunchedEffect
        runCatching {
            featuredRowState.scrollToItem(
                index = initialCarouselIndex,
                scrollOffset = initialCarouselScrollOffsetPx
            )
        }
        hasSeededCarousel = true
    }

    LaunchedEffect(metadataQualifiedFeaturedItems.value) {
        if (metadataQualifiedFeaturedItems.value.isEmpty()) return@LaunchedEffect

        val imageLoader = context.imageLoader
        coroutineScope {
            metadataQualifiedFeaturedItems.value.forEach { item ->
                val itemId = item.id ?: return@forEach
                val versionKey = listOfNotNull(
                    item.imageTagFor(imageType = "Backdrop", targetItemId = itemId),
                    item.imageTagFor(imageType = "Logo", targetItemId = itemId)
                ).distinct().takeIf { it.isNotEmpty() }?.joinToString("|")
                val cachedImages = imageCacheByItemId[itemId]
                if (cachedImages != null && cachedImages.versionKey == versionKey) return@forEach

                launch(Dispatchers.IO) {
                    val backdropTag = item.imageTagFor(
                        imageType = "Backdrop",
                        targetItemId = itemId
                    )
                    val logoTag = item.imageTagFor(
                        imageType = "Logo",
                        targetItemId = itemId
                    )
                    val lowBackdropUrl = mediaRepository.getImageUrlString(
                        itemId = itemId,
                        imageType = "Backdrop",
                        width = 640,
                        height = 360,
                        quality = 70,
                        imageTag = backdropTag
                    )
                    val backdropUrl = mediaRepository.getImageUrlString(
                        itemId = itemId,
                        imageType = "Backdrop",
                        width = 1600,
                        height = 900,
                        quality = 90,
                        imageTag = backdropTag
                    )
                    val logoUrl = mediaRepository.getImageUrlString(
                        itemId = itemId,
                        imageType = "Logo",
                        width = 720,
                        height = 320,
                        quality = 90,
                        imageTag = logoTag
                    )

                    withContext(Dispatchers.Main) {
                        imageCacheByItemId[itemId] = FeatureCardImages(
                            lowBackdropUrl = lowBackdropUrl,
                            backdropUrl = backdropUrl,
                            logoUrl = logoUrl,
                            versionKey = versionKey
                        )
                    }

                    var backdropLoaded = lowBackdropUrl.isNullOrBlank()
                    var logoLoaded = logoUrl.isNullOrBlank()

                    if (!lowBackdropUrl.isNullOrBlank()) {
                        val result = imageLoader.execute(
                            ImageRequest.Builder(context)
                                .data(lowBackdropUrl)
                                .memoryCachePolicy(CachePolicy.ENABLED)
                                .diskCachePolicy(CachePolicy.ENABLED)
                                .networkCachePolicy(CachePolicy.ENABLED)
                                .crossfade(false)
                                .allowHardware(true)
                                .allowRgb565(true)
                                .build()
                        )
                        backdropLoaded = result is SuccessResult
                    }

                    if (!logoUrl.isNullOrBlank()) {
                        val result = imageLoader.execute(
                            ImageRequest.Builder(context)
                                .data(logoUrl)
                                .memoryCachePolicy(CachePolicy.ENABLED)
                                .diskCachePolicy(CachePolicy.ENABLED)
                                .networkCachePolicy(CachePolicy.ENABLED)
                                .crossfade(false)
                                .allowHardware(true)
                                .allowRgb565(true)
                                .build()
                        )
                        logoLoaded = result is SuccessResult
                    }

                    if (backdropLoaded && logoLoaded) {
                        withContext(Dispatchers.Main) {
                            preloadedItemIds.add(itemId)
                        }
                    }
                }
            }
        }
    }

    LaunchedEffect(featuredKeys) {
        if (featuredKeys.isEmpty()) {
            autoScroll = false
            hasSeededCarousel = false
        }
    }

    LaunchedEffect(featuredKeys, isLoading, resolvedFeaturedItems.value.size) {
        if (autoScroll || isLoading) return@LaunchedEffect
        if (resolvedFeaturedItems.value.isNotEmpty()) {
            autoScroll = true
        }
    }

    LaunchedEffect(featuredRowState.isScrollInProgress) {
        if (featuredRowState.isScrollInProgress && !isAutoScrolling) {
            autoScroll = false
            currentPlayingTrailerUrl = null
            isTrailerPlaying = false
            trailerPlaybackCompleted = false
        } else if (!featuredRowState.isScrollInProgress && !isAutoScrolling && !autoScroll) {
            delay(3000L)
            if (!featuredRowState.isScrollInProgress) {
                autoScroll = true
            }
        }
    }

    LaunchedEffect(
        featuredKeys,
        isLoading,
        autoScroll,
        initialCarouselScrollOffsetPx,
        autoplayTrailersEnabled
    ) {
        if (isLoading || resolvedFeaturedItems.value.size <= 1 || !autoScroll) return@LaunchedEffect

        try {
            while (autoScroll) {
                val currentIndex = centeredCardIndex
                val itemIndex = currentIndex % resolvedFeaturedItems.value.size
                val currentItem = resolvedFeaturedItems.value.getOrNull(itemIndex)

                val shouldPlayTrailer = isAutoplayAllowed && currentItem != null
                val trailerUrl = currentItem?.remoteTrailers?.firstOrNull()?.url

                if (shouldPlayTrailer && !trailerUrl.isNullOrBlank()) {
                    currentPlayingTrailerUrl = trailerUrl
                    isTrailerPlaying = true
                    trailerPlaybackCompleted = false

                    val startTime = System.currentTimeMillis()
                    while (!trailerPlaybackCompleted &&
                           System.currentTimeMillis() - startTime < 60_000L &&
                           autoScroll) {
                        delay(1000L)
                    }

                    currentPlayingTrailerUrl = null
                    isTrailerPlaying = false
                    trailerPlaybackCompleted = false
                } else {
                    delay(10_000L)
                }

                if (!autoScroll) break

                val nextIndex = currentIndex + 1
                isAutoScrolling = true
                runCatching {
                    featuredRowState.animateScrollToItem(
                        index = nextIndex,
                        scrollOffset = initialCarouselScrollOffsetPx
                    )
                }
                isAutoScrolling = false
            }
        } finally {
            isAutoScrolling = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(heroViewportHeight)
        ) {
            when {
                resolvedFeaturedItems.value.isNotEmpty() -> {
                    LazyRow(
                        state = featuredRowState,
                        modifier = Modifier
                            .fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = heroSizing.carouselHorizontalPadding,
                            top = heroSizing.carouselTopPadding,
                            end = heroSizing.carouselHorizontalPadding
                        ),
                        horizontalArrangement = Arrangement.spacedBy(heroSizing.carouselItemSpacing),
                        flingBehavior = featuredFlingBehavior
                    ) {
                        items(
                            count = Int.MAX_VALUE,
                            key = { index -> index }
                        ) { index ->
                            val item = resolvedFeaturedItems.value[index % resolvedFeaturedItems.value.size]
                            val cachedImages = item.id?.let { imageCacheByItemId[it] }
                            FeatureHeroCard(
                                item = item,
                                itemIndex = index,
                                listState = featuredRowState,
                                verticalParallaxOffsetPx = verticalParallaxOffsetPx,
                                images = cachedImages,
                                onClick = { onItemClick(item) },
                                heroSizing = heroSizing,
                                modifier = heroCardWidth?.let { Modifier.width(it) }
                                    ?: Modifier.fillParentMaxWidth(heroSizing.cardWidthFraction),
                                isAutoplayTrailersEnabled = isAutoplayAllowed,
                                isCenteredCard = index == centeredCardIndex,
                                onTrailerCompleted = {
                                    trailerPlaybackCompleted = true
                                },
                                currentPlayingTrailerUrl = if (index == centeredCardIndex) currentPlayingTrailerUrl else null
                            )
                        }
                    }
                }

                isLoading || isFeatureAssets -> FeatureHeroSkeleton(
                    heroHeight = heroHeight,
                    modifier = Modifier.padding(top = heroSizing.carouselTopPadding)
                )

                !error.isNullOrBlank() -> FeatureHeroError(
                    error = error,
                    heroHeight = heroHeight,
                    modifier = Modifier.padding(top = heroSizing.carouselTopPadding)
                )

                else -> FeatureHeroError(
                    error = "No featured content available",
                    heroHeight = heroHeight,
                    modifier = Modifier.padding(top = heroSizing.carouselTopPadding)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .align(Alignment.TopStart),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CategoryChipMenu(
                    selectedCategory = selectedCategory,
                    onCategorySelected = onCategorySelected
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ScreenCastButton(
                        onConnectedClick = onCastButtonClick,
                        size = 34.dp
                    )
                    UserProfileAvatar(
                        imageUrl = userProfileImageUrl,
                        serverTypeRaw = sessionSnapshot.serverType,
                        onClick = onProfileClick,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}

private fun hasFeatureHeroAssets(item: BaseItemDto): Boolean {
    val hasLogo = item.parentLogoImageTag?.isNotBlank() == true ||
        item.imageTags
            ?.any { (type, tag) -> type.equals("Logo", ignoreCase = true) && tag.isNotBlank() } == true

    val hasBackdrop = item.backdropImageTags?.any { it.isNotBlank() } == true ||
        item.parentBackdropImageTags?.any { it.isNotBlank() } == true ||
        item.imageTags
            ?.any { (type, tag) -> type.equals("Backdrop", ignoreCase = true) && tag.isNotBlank() } == true

    return hasLogo && hasBackdrop
}

@Composable
private fun CategoryChipMenu(
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val menuOptions = remember(selectedCategory) {
        HomeCategory.all.filterNot { it == selectedCategory }
    }
    var expanded by remember { mutableStateOf(false) }
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "category_arrow"
    )
    val pillShape = RoundedCornerShape(18.dp)
    val glassGradient = Brush.horizontalGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.12f),
            Color.White.copy(alpha = 0.05f)
        )
    )
    val glassBorder = Color.White.copy(alpha = 0.22f)

    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .clip(pillShape)
                .background(glassGradient)
                .border(1.dp, glassBorder, pillShape)
                .clickable { expanded = true }
                .padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.jellycine_logo),
                contentDescription = stringResource(R.string.app_name),
                modifier = Modifier.size(28.dp),
                contentScale = ContentScale.Fit
            )
            Text(
                text = stringResource(HomeCategory.titleRes(selectedCategory)),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(18.dp)
                    .graphicsLayer(rotationZ = arrowRotation)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            containerColor = Color.Transparent,
            shadowElevation = 0.dp,
            tonalElevation = 0.dp,
            border = null,
            modifier = Modifier.background(Color.Transparent)
        ) {
            Column(
                modifier = Modifier.padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                menuOptions.forEach { category ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(pillShape)
                            .background(glassGradient)
                            .border(1.dp, glassBorder, pillShape)
                            .clickable {
                                expanded = false
                                onCategorySelected(category)
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(HomeCategory.titleRes(category)),
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowDown,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.55f),
                            modifier = Modifier
                                .size(16.dp)
                                .graphicsLayer(rotationZ = -90f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureHeroCard(
    item: BaseItemDto,
    itemIndex: Int,
    listState: LazyListState,
    verticalParallaxOffsetPx: Float,
    images: FeatureCardImages?,
    onClick: () -> Unit,
    heroSizing: FeatureHeroSizing,
    modifier: Modifier = Modifier,
    isAutoplayTrailersEnabled: Boolean = false,
    isCenteredCard: Boolean = false,
    onTrailerCompleted: () -> Unit = {},
    currentPlayingTrailerUrl: String? = null
) {
    val context = LocalContext.current
    val itemName = item.name ?: stringResource(R.string.search_result_unknown_title)
    var contentVisible by remember { mutableStateOf(true) }
    val logoAlpha by animateFloatAsState(
        targetValue = if (contentVisible) 1f else 0f,
        label = "hero_logo_alpha"
    )
    val metaAlpha by animateFloatAsState(
        targetValue = if (contentVisible) 1f else 0f,
        label = "hero_meta_alpha"
    )
    val metaOffset by animateFloatAsState(
        targetValue = if (contentVisible) 0f else 10f,
        label = "hero_meta_offset"
    )

    val lowBackdropUrl = images?.lowBackdropUrl ?: images?.backdropUrl
    val backdropUrl = images?.backdropUrl
    val logoUrl = images?.logoUrl
    var lowResImage by remember(item.id, lowBackdropUrl) { mutableStateOf(false) }
    val backdropParallaxShift = remember(verticalParallaxOffsetPx, heroSizing.backdropParallaxMultiplier) {
        verticalParallaxOffsetPx * heroSizing.backdropParallaxMultiplier
    }
    val isCompactHero = heroSizing.isCompact
    val pageOffset by remember(listState, itemIndex) {
        derivedStateOf {
            val visibleItemInfo = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == itemIndex }
            if (visibleItemInfo == null || visibleItemInfo.size == 0) {
                1f
            } else {
                visibleItemInfo.offset.toFloat() / visibleItemInfo.size.toFloat()
            }
        }
    }
    val scrollInfluence = if (isCompactHero) 0f else abs(pageOffset).coerceIn(0f, 1f)
    val contentAlpha = 1f - (0.35f * scrollInfluence)
    val contentScale = 1f - (0.05f * scrollInfluence)
    val contentShift = 12f * scrollInfluence

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(heroSizing.height),
        shape = RoundedCornerShape(heroSizing.cardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (!lowBackdropUrl.isNullOrBlank()) {
                val lowPainter = rememberAsyncImagePainter(
                    model = ImageRequest.Builder(context)
                        .data(lowBackdropUrl)
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .networkCachePolicy(CachePolicy.ENABLED)
                        .crossfade(false)
                        .allowHardware(true)
                        .allowRgb565(true)
                        .build()
                )
                val lowState by lowPainter.state.collectAsState()
                LaunchedEffect(lowState) {
                    if (lowState is AsyncImagePainter.State.Success ||
                        lowState is AsyncImagePainter.State.Error
                    ) {
                        lowResImage = true
                    }
                }

                Image(
                    painter = lowPainter,
                    contentDescription = itemName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            translationY = backdropParallaxShift,
                            scaleX = heroSizing.backdropScale,
                            scaleY = heroSizing.backdropScale
                        )
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                )
            }

            if (!backdropUrl.isNullOrBlank() && lowResImage) {
                val highPainter = rememberAsyncImagePainter(
                    model = ImageRequest.Builder(context)
                        .data(backdropUrl)
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .networkCachePolicy(CachePolicy.ENABLED)
                        .crossfade(true)
                        .allowHardware(true)
                        .allowRgb565(true)
                        .build()
                )
                val highState by highPainter.state.collectAsState()
                val highResImage = highState is AsyncImagePainter.State.Success
                val highAlpha by animateFloatAsState(
                    targetValue = if (highResImage) 1f else 0f,
                    label = "hero_backdrop_high_alpha"
                )

                Image(
                    painter = highPainter,
                    contentDescription = itemName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            translationY = backdropParallaxShift,
                            alpha = highAlpha,
                            scaleX = heroSizing.backdropScale,
                            scaleY = heroSizing.backdropScale
                        )
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Black.copy(alpha = 0.18f),
                                0.50f to Color.Transparent,
                                0.78f to Color.Black.copy(alpha = heroSizing.lowerGradientAlpha),
                                1.0f to Color.Black.copy(alpha = heroSizing.bottomGradientAlpha)
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(heroSizing.bottomFadeHeight)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = heroSizing.bottomGradientAlpha)
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(heroSizing.bottomEdgeHeight)
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Transparent,
                                0.45f to Color.Black.copy(alpha = heroSizing.bottomEdgeAlpha * 0.22f),
                                0.78f to Color.Black.copy(alpha = heroSizing.bottomEdgeAlpha * 0.62f),
                                1.0f to Color.Black.copy(alpha = heroSizing.bottomEdgeAlpha)
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithCache {
                        val radius = size.maxDimension * 0.72f
                        val brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = heroSizing.vignetteAlpha)
                            ),
                            center = Offset(size.width / 2f, size.height / 2f),
                            radius = radius
                        )
                        onDrawBehind { drawRect(brush) }
                    }
            )

            if (isAutoplayTrailersEnabled && isCenteredCard) {
                val trailerUrl = currentPlayingTrailerUrl ?: item.remoteTrailers?.firstOrNull()?.url
                if (!trailerUrl.isNullOrBlank()) {
                    InlineTrailerPlayer(
                        trailerUrl = trailerUrl,
                        isVisible = isCenteredCard,
                        modifier = Modifier.fillMaxSize(),
                        onPlaybackCompleted = onTrailerCompleted,
                        onError = { onTrailerCompleted() }
                    )
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(
                        horizontal = heroSizing.contentHorizontalPadding,
                        vertical = heroSizing.contentVerticalPadding
                    )
                    .graphicsLayer(
                        alpha = contentAlpha,
                        scaleX = contentScale,
                        scaleY = contentScale,
                        translationY = contentShift
                    ),
                verticalArrangement = Arrangement.spacedBy(heroSizing.contentSpacing),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!logoUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(logoUrl)
                            .memoryCachePolicy(CachePolicy.ENABLED)
                            .diskCachePolicy(CachePolicy.ENABLED)
                            .networkCachePolicy(CachePolicy.ENABLED)
                            .crossfade(false)
                        .allowHardware(true)
                        .allowRgb565(false)
                        .build(),
                        contentDescription = stringResource(
                            R.string.feature_logo_content_description,
                            itemName
                        ),
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .height(heroSizing.logoHeight)
                            .fillMaxWidth(heroSizing.logoWidthFraction)
                            .graphicsLayer(
                                alpha = logoAlpha
                            )
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.72f)
                            .height(heroSizing.logoFallbackHeight)
                            .background(Color.Black, RoundedCornerShape(4.dp))
                    )
                }

                FeatureHeroMetadataRow(
                    item = item,
                    isCompactHero = isCompactHero,
                    metaAlpha = metaAlpha,
                    metaOffset = metaOffset
                )
            }
        }
    }
}

@Composable
internal fun UserProfileAvatar(
    imageUrl: String?,
    serverTypeRaw: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        ProfileImageLoader(
            imageUrl = imageUrl,
            serverTypeRaw = serverTypeRaw,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun FeatureHeroSkeleton(
    heroHeight: Dp,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(heroHeight),
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        )
    }
}

@Composable
private fun FeatureHeroError(
    error: String,
    heroHeight: Dp,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(heroHeight),
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141414))
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = error,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.76f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    }
}