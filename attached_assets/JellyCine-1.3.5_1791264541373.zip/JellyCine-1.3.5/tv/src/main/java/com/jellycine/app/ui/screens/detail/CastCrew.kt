package com.jellycine.app.ui.screens.detail

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jellycine.data.model.BaseItemPerson

@Composable
internal fun DirectorCreditRow(
    label: String,
    directors: List<BaseItemPerson>,
    onPersonClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (directors.isEmpty()) return

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.White,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.width(6.dp))

        Row {
            directors.forEachIndexed { index, person ->
                val personId = person.id
                val canOpenPerson = !personId.isNullOrBlank()
                val name = person.name ?: "Unknown"
                Text(
                    text = name + if (index < directors.lastIndex) ", " else "",
                    fontSize = 12.sp,
                    color = Color(0xFF89ECFF),
                    modifier = Modifier.clickable(enabled = canOpenPerson) {
                        personId?.let(onPersonClick)
                    }
                )
            }
        }
    }
}